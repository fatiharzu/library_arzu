package com.library.mapper;

import com.library.domain.Loan;
import com.library.dto.LoanDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface LoanMapper {
    LoanDTO loanToLonaDTO(Loan loan);
}
