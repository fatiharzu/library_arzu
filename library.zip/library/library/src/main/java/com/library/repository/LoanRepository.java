package com.library.repository;

import com.library.domain.Loan;
import com.library.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanRepository extends JpaRepository<Loan,Long> {
    @EntityGraph(attributePaths = {"book","user"})
    Page<Loan> findAllByUser(User user, Pageable pageable);
}
