package com.library.exception.message;


public class ErrorMessage {
    public final static String RESOURCE_NOT_FOUND_EXCEPTION="Resource with id %s not found";
    public final static String ROL_NOT_FOUND_EXCEPTION="Role: %s not found";
    public final static String USER_NOT_FOUND_EXCEPTION="User: %s not found";
    public final static String JWT_TOKEN_ERROR_MESSAGE="Jwt token validation error : %s";
    public final static String EMAIL_CONFLICT_EXCEPTION="E mail already registered : %s";
    public final static String PRINCIPAL_FOUND_MESSAGE = "User not found";
    public final static String NOT_PERMITED_METOD_MESSAGE = "You dont have permission to change this data";

    public final static String PASSWORD_NOT_MATCH_MESSAGE = "Your ex password is not match";
    public final static String IMAGE_NOT_FOUND_EXCEPTION="Image with id %s not found";
    public final static String IMAGE_CONFLICT_EXCEPTION="This image already used : %s";
    public final static String CAR_NOT_FOUND_EXCEPTION="Car with id %s not found";
    public final static String RESERVATION_TIME_INCORRECT="Reservation pickup timme or dropOfftime is incorrect";
    public final static String CAR_NOT_AVAILABLE_MESSAGE = "Car is not available for selected time ";

    public final static String RESERVATION_STATUS_CANT_CHANGE_MESSAGE = "Reservation can't be updated for canceled or done reservations";

    public final static String CAR_USED_BY_RESERVATION_MESSAGE = "Car couldn't be deleted. Car is used by a reservation ";
    public final static String USER_USED_BY_RESERVATION_MESSAGE = "User couldn't be deleted. User is used by a reservation ";
    public final static String EXCEL_REPORT_ERROR_MESSAGE = "Error occured while generating excel report";


}
