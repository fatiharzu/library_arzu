package com.library.mapper;

import com.library.domain.User;
import com.library.dto.RegisterDTO;
import com.library.dto.UserDTO;
import com.library.dto.request.RegisterRequest;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface UserMapper {
    User registerRequestToUser(RegisterRequest registerRequest);

    RegisterDTO userToRegisterDTO(User user);
//    @Mapping(target = "password",ignore = true)
//    @Mapping(target = "resetPasswordCode",ignore = true)
    UserDTO userToUserDTO(User user);





}
