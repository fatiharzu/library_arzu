package com.library.service;

import com.library.domain.Loan;
import com.library.domain.User;
import com.library.dto.LoanDTO;
import com.library.mapper.LoanMapper;
import com.library.repository.LoanRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class LoanService {

    private final LoanRepository loanRepository;
    private final LoanMapper loanMapper;

    public LoanService(LoanRepository loanRepository, LoanMapper loanMapper) {
        this.loanRepository = loanRepository;
        this.loanMapper = loanMapper;
    }

    public Page<LoanDTO> getLoansByPage(User user, Pageable pageable) {
        Page<Loan> loans =loanRepository.findAllByUser(user, pageable);
        return loans.map(loanMapper::loanToLonaDTO);
    }
}
