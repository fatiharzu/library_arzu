package com.library.controller;

import com.library.dto.LoanDTO;
import com.library.dto.UserDTO;
import com.library.service.UserService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('MEMBER') or hasRole('STAFF')")
    public ResponseEntity<UserDTO> getAuthenticatedUser(){
    UserDTO user=userService.getAuthenticatedUser();
    return ResponseEntity.ok(user);
    }

    @GetMapping("/loans")
    public ResponseEntity<Page<LoanDTO>> getLoansByUser(@RequestParam(required = false ,value="page") int page,
                                                        @RequestParam(required = false ,value="size") int size,
                                                        @RequestParam(required = false ,value="sort") String prop,
                                                        @RequestParam(required = false ,value="type") Sort.Direction type){

        Pageable pageable= PageRequest.of(page, size, Sort.by(type, prop));
        Page<LoanDTO> loans=userService.getLoansByUser(pageable);
        return ResponseEntity.ok(loans);
    }
}