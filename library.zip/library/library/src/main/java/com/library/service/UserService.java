package com.library.service;

import com.library.domain.Role;
import com.library.domain.User;
import com.library.domain.enums.RoleType;
import com.library.dto.LoanDTO;
import com.library.dto.RegisterDTO;
import com.library.dto.UserDTO;
import com.library.dto.request.RegisterRequest;
import com.library.exception.ConflictException;
import com.library.exception.ResourceNotFoundException;
import com.library.exception.message.ErrorMessage;
import com.library.mapper.UserMapper;
import com.library.repository.UserRepository;
import com.library.security.SecurityUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class UserService {
    private final UserRepository userRepository;

    private final UserMapper userMapper;

    private final RoleService roleService;
    private final PasswordEncoder passwordEncoder;

    private final LoanService loanService;


    public UserService(UserRepository userRepository, UserMapper userMapper, RoleService roleService, @Lazy PasswordEncoder passwordEncoder, LoanService loanService) {
        this.userRepository = userRepository;
        this.userMapper = userMapper;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;

        this.loanService = loanService;
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email).orElseThrow(()->new ResourceNotFoundException(
                String.format(ErrorMessage.USER_NOT_FOUND_EXCEPTION, email)
        ));
    }

    public RegisterDTO register(RegisterRequest registerRequest) {
        if(userRepository.existsByEmail(registerRequest.getEmail())){
            throw new ConflictException(String.format(ErrorMessage.EMAIL_CONFLICT_EXCEPTION,registerRequest.getEmail()));
        }
    User user=userMapper.registerRequestToUser(registerRequest);
        Role role=roleService.getRoleByType(RoleType.ROLE_MEMBER);
        Set<Role> roles=new HashSet<>();
        roles.add(role);
        user.setRoles(roles);

        String encodedPassword=passwordEncoder.encode(registerRequest.getPassword());
        user.setPassword(encodedPassword);
        userRepository.save(user);
        user.setPassword(registerRequest.getPassword());
        return userMapper.userToRegisterDTO(user);

    }

    public UserDTO getAuthenticatedUser() {
        User user=getCurrentlyUser();
        return userMapper.userToUserDTO(user);
    }

    private User getCurrentlyUser() {
        String email= SecurityUtils.getCurrentUserEmail().orElseThrow(()->new ResourceNotFoundException(
                ErrorMessage.PRINCIPAL_FOUND_MESSAGE));
        return getUserByEmail(email);
    }


    public Page<LoanDTO> getLoansByUser(Pageable pageable) {
        User user=getCurrentlyUser();
       return loanService.getLoansByPage(user, pageable);
    }

}
