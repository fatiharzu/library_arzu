INSERT INTO public.t_role(
	type)
	VALUES ('ROLE_MEMBER');

INSERT INTO public.t_role(
    type)
    VALUES ('ROLE_STAFF');

INSERT INTO public.t_role(
	type)
	VALUES ('ROLE_ADMIN');